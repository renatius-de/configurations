<?php
<#if namespace?? && namespace?length &gt; 0>
namespace ${namespace};
</#if>

/**
 * @author ${user}
 */
trait ${name} {
}
