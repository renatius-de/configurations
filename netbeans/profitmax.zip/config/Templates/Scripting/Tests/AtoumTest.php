<?php
namespace tests\unit;

use atoum;

/**
 * @author ${user}
 */
class ${name} extends atoum {
    public function testSkipped() {
        $this->skip('This test was skipped');
    }
}
