<?php
/**
 * @author ${user}
 */
ini_set('include_path', ini_get('include_path')%INCLUDE_PATH%);
